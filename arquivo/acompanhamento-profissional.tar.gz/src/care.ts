import { useRouter } from 'expo-router';

import { DOCUMENTS, MESSAGES, ORIENTATIONS, PROFESSIONALS, SCOPES } from '@/content';
import { DAY, fmt, gestation, useStore } from '@/store';
import { colors } from '@/theme';

// Estado derivado do acompanhamento pela equipe, compartilhado entre as telas da gestante.
export function useCare() {
  const { s, set } = useStore();
  const router = useRouter();
  const { today, week } = gestation(s);

  const dateLabel = (off: number) => (off === 0 ? 'hoje' : fmt(new Date(today.getTime() + off * DAY), { day: 'numeric', month: 'short' }).replace('.', ''));

  const orients = ORIENTATIONS.map((o) => ({
    ...o,
    dateLabel: dateLabel(o.off),
    isNew: !s.reads[o.id],
    open: () => {
      set({ orientSel: o.id });
      router.push('/orientacao');
    },
  }));

  const allMessages = [...MESSAGES, ...s.sentMessages];
  const teamCount = allMessages.filter((m) => m.who !== 'me').length;
  const unreadMessages = Math.max(0, teamCount - s.msgSeen);
  const openMessages = () => {
    set({ msgSeen: teamCount });
    router.push('/mensagens');
  };

  const allDocs = [...s.sentDocs, ...DOCUMENTS];
  const hemoPending = !s.reqDone.r1;
  const scopeText = SCOPES.filter(([k]) => s.scope[k]).map(([, label]) => label.toLowerCase()).join(', ') || 'nenhum dado';
  const professional = (p: (typeof PROFESSIONALS)[number]) => ({ ...p, scope: p.scope ?? scopeText, scopeShort: p.scopeShort ?? scopeText });
  const team = PROFESSIONALS.filter((p) => s.links[p.id] === 'active').map(professional);
  const access = PROFESSIONALS.filter((p) => s.links[p.id]).map((p) => ({ ...professional(p), active: s.links[p.id] === 'active' }));

  const attention: { kicker: string; title: string; dot: string; go: () => void }[] = [];
  orients.filter((o) => o.isNew).slice(0, 1).forEach((o) => attention.push({ kicker: 'Nova orientação · ' + o.from, title: o.title, dot: colors.terra, go: o.open }));
  if (hemoPending) attention.push({ kicker: 'Solicitação · Dra. Helena Prado', title: 'Enviar o resultado do hemograma', dot: colors.caramel, go: () => router.push('/documentos') });
  if (s.invite) attention.push({ kicker: 'Convite de vínculo', title: 'Camila Torres, nutricionista', dot: colors.sageDot, go: () => router.push('/convite') });
  if (unreadMessages > 0) attention.push({ kicker: 'Mensagens', title: `${unreadMessages} ${unreadMessages > 1 ? 'novas mensagens' : 'nova mensagem'} da equipe`, dot: colors.ink, go: openMessages });

  const notifications: { title: string; text: string; time: string; go: () => void; unread?: boolean }[] = [];
  orients.filter((o) => o.isNew).forEach((o) => notifications.push({ title: 'Nova orientação', text: `${o.title} · ${o.from}`, time: o.dateLabel, go: o.open, unread: true }));
  if (hemoPending) notifications.push({ title: 'Solicitação de documento', text: 'Dra. Helena Prado pediu o resultado do hemograma.', time: 'ontem', go: () => router.push('/documentos'), unread: true });
  if (s.invite) notifications.push({ title: 'Convite de vínculo', text: 'Camila Torres, nutricionista, quer acompanhar você.', time: 'hoje', go: () => router.push('/convite'), unread: true });
  notifications.push({ title: 'Mensagem da equipe', text: 'Equipe Clínica Bem Nascer respondeu sua pergunta.', time: 'hoje, 9:15', go: openMessages, unread: unreadMessages > 0 });
  notifications.push({ title: `Semana ${week}`, text: 'O conteúdo da sua nova semana está disponível.', time: 'seg', go: () => router.push('/semana') });
  notifications.push({ title: 'Lembrete de consulta', text: 'Consulta pré-natal em 4 dias, às 14h30.', time: 'dom', go: () => router.push('/consultas') });

  return {
    orients,
    dateLabel,
    allMessages,
    unreadMessages,
    openMessages,
    allDocs,
    hemoPending,
    team,
    access,
    attention,
    notifications,
    hasUnreadNotif: !s.notifSeen && notifications.some((n) => n.unread),
  };
}
