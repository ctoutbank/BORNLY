import { View } from 'react-native';

import { useCare } from '@/care';
import { useStore } from '@/store';
import { colors } from '@/theme';
import { Card, CheckMark, PageHeader, PrimaryButton, Sans, Screen, Title, Tag, TextButton, Wrap } from '@/ui';

export default function Orientacao() {
  const { s, set, flash } = useStore();
  const care = useCare();
  const o = care.orients.find((x) => x.id === s.orientSel) ?? care.orients[0];
  return (
    <Screen gap={20}>
      <PageHeader title="Orientação" sub={`${o.from} · ${o.role}`} fallback="/hoje" />
      <Card radius={28} style={{ padding: 22, gap: 14 }}>
        <Wrap gap={6}>
          <Tag label={o.kind} fg={colors.terra} bg={colors.peach} />
          <Tag label={o.valid} fg={colors.sageInk} bg={colors.sage} />
        </Wrap>
        <Title s={22}>{o.title}</Title>
        <Sans s={14} lh={1.6} c={colors.body}>{o.body}</Sans>
        <View style={{ gap: 10, borderTopWidth: 1, borderTopColor: colors.lineSoft, paddingTop: 14 }}>
          {o.steps.map((text, i) => (
            <View key={text} style={{ flexDirection: 'row', gap: 12 }}>
              <Title s={14} lh={1.45} c={colors.terra} style={{ width: 16 }}>{i + 1}</Title>
              <Sans s={14} lh={1.45} style={{ flex: 1 }}>{text}</Sans>
            </View>
          ))}
        </View>
        <Sans s={12} c={colors.muted}>Publicada {o.dateLabel} por {o.from}</Sans>
      </Card>
      {o.isNew ? (
        <PrimaryButton
          label="Confirmar leitura"
          onPress={() => {
            set((st) => ({ reads: { ...st.reads, [o.id]: true } }));
            flash('Leitura confirmada');
          }}
        />
      ) : (
        <View style={{ height: 58, borderRadius: 999, backgroundColor: colors.sage, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <CheckMark color="#3F5A51" w={13} h={10} />
          <Sans s={14} w={600} c="#3F5A51">Leitura confirmada</Sans>
        </View>
      )}
      <View style={{ marginTop: -10 }}>
        <TextButton label="Tenho uma dúvida sobre esta orientação" w={600} c={colors.terra} onPress={care.openMessages} />
      </View>
      <Sans s={12} lh={1.5} c={colors.muted} style={{ paddingHorizontal: 4, marginTop: -8 }}>A confirmação avisa a equipe que você leu. Se algo não ficou claro, pergunte antes de seguir.</Sans>
    </Screen>
  );
}
