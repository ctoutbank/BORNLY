import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { useCare } from '@/care';
import { gestation, nextAppointment, useStore } from '@/store';
import { colors } from '@/theme';
import { Card, CheckMark, Chevron, Initials, Overline, PageHeader, Press, Sans, Screen, Title, Tag } from '@/ui';

export default function Acompanhamento() {
  const { s } = useStore();
  const router = useRouter();
  const care = useCare();
  const next = nextAppointment(gestation(s).today);
  const requests = [
    { text: 'Enviar o resultado do hemograma', done: !care.hemoPending, go: () => router.push('/documentos') },
    { text: 'Registrar como você está nesta semana', done: s.diaryDone, go: () => router.push('/diario') },
  ];

  return (
    <Screen gap={20}>
      <PageHeader title="Meu acompanhamento" sub="Sua equipe e o que ela enviou" fallback="/hoje" />
      <Card bg={colors.ink} radius={28} style={{ padding: 20, gap: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <Initials text="HP" bg={colors.photo} size={52} fontSize={18} />
          <View style={{ flex: 1, minWidth: 0 }}>
            <Overline c={colors.onInkSoft} style={{ fontSize: 11 }}>Médica responsável</Overline>
            <Title s={18} c={colors.bg} style={{ marginTop: 4 }}>Dra. Helena Prado</Title>
            <Sans s={12} c={colors.onInkMid} style={{ marginTop: 2 }}>Obstetra · CRM-SP 123456</Sans>
          </View>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12, borderTopWidth: 1, borderTopColor: 'rgba(244,236,227,.15)', paddingTop: 14 }}>
          <Sans s={12} c={colors.onInkMid}>Clínica Bem Nascer</Sans>
          <Sans s={12} c={colors.bg} style={{ flexShrink: 1, textAlign: 'right' }}>Próxima: {next.when}</Sans>
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Press onPress={care.openMessages} style={{ flex: 1, height: 48, borderRadius: 999, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}>
            <Sans s={13} w={600}>Mensagem</Sans>
          </Press>
          <Press onPress={() => router.push('/consultas')} style={{ flex: 1, height: 48, borderRadius: 999, borderWidth: 1, borderColor: 'rgba(244,236,227,.3)', alignItems: 'center', justifyContent: 'center' }}>
            <Sans s={13} w={600} c={colors.bg}>Consultas</Sans>
          </Press>
        </View>
      </Card>
      <Card bg={colors.sage} radius={20} style={{ paddingVertical: 14, paddingHorizontal: 16 }}>
        <Sans s={13} lh={1.5} c="#3F5A51">Mensagens e registros são vistos pela equipe em dias úteis, das 8h às 18h. Não é monitoramento em tempo real: em sinais de alerta, procure a maternidade sem esperar resposta.</Sans>
      </Card>
      <View>
        <Title s={18} style={{ marginBottom: 12 }}>Orientações recebidas</Title>
        <View style={{ gap: 8 }}>
          {care.orients.map((o) => (
            <Press key={o.id} onPress={o.open} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.card, borderRadius: 20, paddingVertical: 14, paddingHorizontal: 16, minHeight: 64 }}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Sans s={12} c={colors.muted}>{o.from} · {o.dateLabel}</Sans>
                <Sans s={14} w={600} style={{ marginTop: 3 }}>{o.title}</Sans>
              </View>
              {o.isNew ? <Tag label="Nova" fg={colors.bg} bg={colors.ink} /> : <Tag label="Lida" fg={colors.mutedStrong} bg={colors.sand} />}
            </Press>
          ))}
        </View>
      </View>
      <View>
        <Title s={18} style={{ marginBottom: 12 }}>Solicitações da equipe</Title>
        <Card radius={24} style={{ paddingVertical: 4, paddingHorizontal: 16 }}>
          {requests.map((r, i) => (
            <Press key={r.text} onPress={r.go} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14, minHeight: 60, borderBottomWidth: i === requests.length - 1 ? 0 : 1, borderBottomColor: colors.lineSoft }}>
              <View style={{ width: 26, height: 26, borderRadius: 13, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', backgroundColor: r.done ? colors.ink : 'transparent', borderColor: r.done ? colors.ink : colors.check }}>
                {r.done ? <CheckMark color={colors.bg} /> : null}
              </View>
              <View style={{ flex: 1 }}>
                <Sans s={14} w={600} c={r.done ? colors.muted : colors.ink}>{r.text}</Sans>
                <Sans s={12} c={colors.muted} style={{ marginTop: 2 }}>{r.done ? 'Concluída' : 'Solicitada por Dra. Helena Prado'}</Sans>
              </View>
            </Press>
          ))}
        </Card>
      </View>
      <View>
        <Title s={18} style={{ marginBottom: 12 }}>Equipe vinculada</Title>
        <View style={{ gap: 8 }}>
          {care.team.map((p) => (
            <Card key={p.id} radius={20} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 12, paddingHorizontal: 16 }}>
              <Initials text={p.initials} bg={p.avatar} />
              <View style={{ flex: 1, minWidth: 0 }}>
                <Sans s={14} w={600}>{p.name}</Sans>
                <Sans s={12} c={colors.muted} style={{ marginTop: 2 }}>{p.role} · {p.scopeShort}</Sans>
              </View>
            </Card>
          ))}
          {s.invite ? (
            <Press onPress={() => router.push('/convite')} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.peach, borderRadius: 20, paddingVertical: 14, paddingHorizontal: 16, minHeight: 64 }}>
              <View style={{ flex: 1 }}>
                <Sans s={14} w={600} c={colors.terraText}>Convite de Camila Torres</Sans>
                <Sans s={12} c={colors.terraDark} style={{ marginTop: 2 }}>Nutricionista · aguardando sua autorização</Sans>
              </View>
              <Chevron color={colors.terra} />
            </Press>
          ) : null}
        </View>
      </View>
    </Screen>
  );
}
