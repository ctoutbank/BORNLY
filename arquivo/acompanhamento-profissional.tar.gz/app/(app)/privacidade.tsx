import { View } from 'react-native';

import { useCare } from '@/care';
import { PRIVACY_TOGGLES } from '@/content';
import { useStore } from '@/store';
import { colors } from '@/theme';
import { Card, Initials, PageHeader, Press, Sans, Screen, Title, ToggleRow } from '@/ui';

export default function Privacidade() {
  const { s, set, flash } = useStore();
  const care = useCare();
  const setLink = (id: string, value: 'active' | 'revoked', message: string) => {
    set((st) => ({ links: { ...st.links, [id]: value } }));
    flash(message);
  };
  return (
    <Screen gap={20}>
      <PageHeader title="Privacidade" sub="Você decide quem vê o quê" fallback="/hoje" />
      <View>
        <Title s={18} style={{ marginBottom: 12 }}>Profissionais com acesso</Title>
        <View style={{ gap: 8 }}>
          {care.access.map((p) => (
            <Card key={p.id} radius={24} style={{ paddingVertical: 16, paddingHorizontal: 18, gap: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <Initials text={p.initials} bg={p.avatar} />
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Sans s={14} w={600}>{p.name}</Sans>
                  <Sans s={12} c={colors.muted} style={{ marginTop: 2 }}>{p.role} · {p.since}</Sans>
                </View>
              </View>
              <Sans s={12} lh={1.45} c={colors.mutedStrong}>Vê: {p.scope}</Sans>
              {p.active ? (
                <Press onPress={() => setLink(p.id, 'revoked', 'Acesso encerrado')} style={{ alignSelf: 'flex-start', borderWidth: 1.5, borderColor: colors.line, borderRadius: 999, paddingHorizontal: 16, height: 40, justifyContent: 'center' }}>
                  <Sans s={13} w={600} c={colors.terraDark}>Revogar acesso</Sans>
                </Press>
              ) : (
                <>
                  <View style={{ backgroundColor: colors.peach, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 12 }}>
                    <Sans s={12} lh={1.45} c={colors.terraDark}>Acesso encerrado hoje. Registros que o profissional é obrigado por lei a guardar continuam com ele.</Sans>
                  </View>
                  <Press onPress={() => setLink(p.id, 'active', 'Acesso autorizado novamente')} style={{ alignSelf: 'flex-start', minHeight: 36, justifyContent: 'center' }}>
                    <Sans s={13} w={600} c={colors.terra}>Autorizar novamente</Sans>
                  </Press>
                </>
              )}
            </Card>
          ))}
        </View>
      </View>
      <Card radius={24} style={{ paddingVertical: 4, paddingHorizontal: 18 }}>
        {PRIVACY_TOGGLES.map(([k, label, sub], i) => (
          <ToggleRow key={k} label={label} sub={sub} on={!!s.priv[k]} last={i === PRIVACY_TOGGLES.length - 1} onToggle={() => set((st) => ({ priv: { ...st.priv, [k]: !st.priv[k] } }))} />
        ))}
      </Card>
      <View>
        <Title s={18} style={{ marginBottom: 12 }}>Meus dados</Title>
        <Card radius={24} style={{ paddingVertical: 4, paddingHorizontal: 18 }}>
          <Press onPress={() => flash('Cópia dos dados ainda não disponível')} style={{ paddingVertical: 16, minHeight: 56, justifyContent: 'center', borderBottomWidth: 1, borderBottomColor: colors.lineSoft }}>
            <Sans s={14} w={600}>Baixar uma cópia dos meus dados</Sans>
          </Press>
          <Press onPress={() => flash('Exclusão da conta ainda não disponível')} style={{ paddingVertical: 16, minHeight: 56, justifyContent: 'center' }}>
            <Sans s={14} w={600} c={colors.terraDark}>Solicitar exclusão da conta</Sans>
          </Press>
        </Card>
      </View>
      <Sans s={12} lh={1.5} c={colors.muted} style={{ paddingHorizontal: 4 }}>Dados de saúde são dados sensíveis pela LGPD. Cada compartilhamento depende da sua autorização e fica registrado.</Sans>
    </Screen>
  );
}
