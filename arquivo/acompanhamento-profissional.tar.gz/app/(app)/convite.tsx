import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { SCOPES } from '@/content';
import { useStore } from '@/store';
import { colors } from '@/theme';
import { Card, Initials, PageHeader, PrimaryButton, Sans, Screen, Title, Tag, TextButton, ToggleRow } from '@/ui';

export default function Convite() {
  const { s, set, flash } = useStore();
  const router = useRouter();
  return (
    <Screen gap={20}>
      <PageHeader title="Convite de vínculo" sub="Clínica Bem Nascer" fallback="/hoje" />
      {s.invite ? (
        <>
          <Card radius={28} style={{ padding: 22, alignItems: 'center', gap: 8 }}>
            <Initials text="CT" bg={colors.sage} size={76} fontSize={26} />
            <Title s={22} style={{ marginTop: 4 }}>Camila Torres</Title>
            <Sans s={13} c={colors.muted}>Nutricionista · CRN-3 45678</Sans>
            <Tag label="Registro profissional verificado" fg={colors.sageInk} bg={colors.sage} />
            <Sans s={13} lh={1.55} c={colors.body} style={{ marginTop: 6, textAlign: 'center' }}>Indicada pela Dra. Helena Prado para acompanhar sua alimentação até o parto.</Sans>
          </Card>
          <View>
            <Title s={18}>O que Camila poderá ver</Title>
            <Sans s={12} c={colors.muted} style={{ marginTop: 4, marginBottom: 12 }}>Só o que você ativar. Dá para mudar depois em Privacidade.</Sans>
            <Card radius={24} style={{ paddingVertical: 4, paddingHorizontal: 18 }}>
              {SCOPES.map(([k, label, sub], i) => (
                <ToggleRow key={k} label={label} sub={sub} on={!!s.scope[k]} last={i === SCOPES.length - 1} onToggle={() => set((st) => ({ scope: { ...st.scope, [k]: !st.scope[k] } }))} />
              ))}
            </Card>
          </View>
          <View style={{ gap: 4 }}>
            <PrimaryButton
              label="Autorizar e vincular"
              onPress={() => {
                set((st) => ({ invite: false, links: { ...st.links, camila: 'active' } }));
                flash('Camila Torres agora faz parte da sua equipe');
                router.replace('/acompanhamento');
              }}
            />
            <TextButton
              label="Recusar convite"
              onPress={() => {
                set({ invite: false });
                flash('Convite recusado. Nada foi compartilhado.');
                router.dismissTo('/hoje');
              }}
            />
          </View>
        </>
      ) : (
        <Card style={{ paddingVertical: 28, paddingHorizontal: 22 }}>
          <Sans s={14} lh={1.5} c={colors.muted} style={{ textAlign: 'center' }}>Nenhum convite pendente. Quando um profissional convidar você, ele aparece aqui para sua autorização.</Sans>
        </Card>
      )}
    </Screen>
  );
}
