import { ScrollView, View } from 'react-native';

import { useCare } from '@/care';
import { DOC_FILTERS, PregnancyDoc } from '@/content';
import { useStore } from '@/store';
import { colors } from '@/theme';
import { Card, CircleButton, PageHeader, Plus, Press, Sans, Screen, Title, Tag } from '@/ui';

export default function Documentos() {
  const { s, set, flash } = useStore();
  const care = useCare();
  const pushDoc = (doc: Omit<PregnancyDoc, 'id' | 'by' | 'off'>, message: string, done?: boolean) => {
    set((st) => ({
      sentDocs: [{ ...doc, id: `u${st.sentDocs.length}`, by: 'Você', off: 0 }, ...st.sentDocs],
      reqDone: done ? { ...st.reqDone, r1: true } : st.reqDone,
    }));
    flash(message);
  };
  const docs = care.allDocs.filter((d) => s.docFilter === 'Todos' || d.type === s.docFilter);

  return (
    <Screen gap={18}>
      <PageHeader
        title="Documentos da gravidez"
        sub={`${care.allDocs.length} documentos`}
        fallback="/saude"
        right={<CircleButton label="Adicionar documento" onPress={() => pushDoc({ title: 'Cartão de vacinação', type: 'Laudos', fmt: 'IMG' }, 'Documento enviado para sua equipe')}><Plus color={colors.ink} /></CircleButton>}
      />
      {care.hemoPending ? (
        <Card bg={colors.peach} radius={24} style={{ padding: 18, gap: 12 }}>
          <View>
            <Sans s={12} w={600} c={colors.terraDark}>Dra. Helena Prado solicitou</Sans>
            <Title s={18} lh={1.25} style={{ marginTop: 4 }}>Resultado do hemograma</Title>
          </View>
          <Press onPress={() => pushDoc({ title: 'Resultado do hemograma', type: 'Exames', fmt: 'PDF' }, 'Enviado para Dra. Helena Prado', true)} style={{ height: 46, borderRadius: 999, backgroundColor: colors.ink, alignItems: 'center', justifyContent: 'center' }}>
            <Sans s={13} w={600} c={colors.bg}>Enviar arquivo</Sans>
          </Press>
        </Card>
      ) : null}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -20, flexGrow: 0 }} contentContainerStyle={{ gap: 6, paddingHorizontal: 20 }}>
        {DOC_FILTERS.map((l) => {
          const on = s.docFilter === l;
          return (
            <Press key={l} accessibilityState={{ selected: on }} onPress={() => set({ docFilter: l })} style={{ borderRadius: 999, paddingHorizontal: 16, minHeight: 42, justifyContent: 'center', backgroundColor: on ? colors.ink : colors.card }}>
              <Sans s={13} w={600} c={on ? colors.bg : colors.ink}>{l}</Sans>
            </Press>
          );
        })}
      </ScrollView>
      <View style={{ gap: 8 }}>
        {docs.map((d) => (
          <Card key={d.id} radius={20} style={{ flexDirection: 'row', gap: 14, alignItems: 'center', paddingVertical: 12, paddingHorizontal: 14 }}>
            <View style={{ width: 46, height: 54, borderRadius: 12, backgroundColor: colors.sand, alignItems: 'center', justifyContent: 'center' }}>
              <Sans s={11} w={700} c={colors.mutedStrong} style={{ letterSpacing: 0.4 }}>{d.fmt}</Sans>
            </View>
            <View style={{ flex: 1, minWidth: 0, gap: 2 }}>
              <Sans s={14} w={600}>{d.title}</Sans>
              <Sans s={12} c={colors.muted}>Enviado por {d.by} · {care.dateLabel(d.off)}</Sans>
              <View style={{ marginTop: 5 }}>
                {d.team ? <Tag label="Enviado pela equipe" fg={colors.terra} bg={colors.peach} /> : d.rev ? <Tag label={`Revisado por ${d.rev}`} fg={colors.sageInk} bg={colors.sage} /> : <Tag label="Aguardando revisão" fg={colors.mutedStrong} bg={colors.sand} />}
              </View>
            </View>
          </Card>
        ))}
      </View>
      <Sans s={12} lh={1.5} c={colors.muted} style={{ paddingHorizontal: 4 }}>Cada documento registra quem enviou, quando e quem revisou. Só profissionais autorizados por você veem esta pasta.</Sans>
    </Screen>
  );
}
