import { useRouter } from 'expo-router';
import { View } from 'react-native';

import { useCare } from '@/care';
import { fmt, gestation, useStore } from '@/store';
import { colors } from '@/theme';
import { Card, Chevron, Initials, PageHeader, Press, Sans, Screen, Title } from '@/ui';

export default function Perfil() {
  const { s } = useStore();
  const router = useRouter();
  const care = useCare();
  const g = gestation(s);
  const rows = [
    { label: 'Meu acompanhamento', sub: 'Dra. Helena Prado e equipe', go: () => router.push('/acompanhamento') },
    { label: 'Mensagens', sub: 'Fale com sua equipe', go: care.openMessages, badge: care.unreadMessages },
    { label: 'Documentos da gravidez', sub: `${care.allDocs.length} documentos`, go: () => router.push('/documentos') },
    { label: 'Notificações', sub: 'Central de avisos', go: () => router.push('/notificacoes') },
    { label: 'Privacidade e consentimentos', sub: `${care.access.filter((a) => a.active).length} profissionais com acesso`, go: () => router.push('/privacidade') },
    { label: 'Dados da gravidez', sub: 'Corrigir DUM, DPP ou idade gestacional', go: () => router.push('/date') },
  ];
  return (
    <Screen gap={20}>
      <PageHeader title="Perfil" fallback="/hoje" />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16, paddingTop: 4, paddingHorizontal: 4 }}>
        <Initials text={(s.name || 'M').trim().charAt(0).toUpperCase()} bg={colors.avatar} size={64} fontSize={26} />
        <View style={{ flex: 1 }}>
          <Title s={22}>{s.name || 'você'}</Title>
          <Sans s={13} c={colors.muted} style={{ marginTop: 4 }}>{g.week} semanas · DPP {fmt(g.due, { day: 'numeric', month: 'short', year: 'numeric' }).replace('.', '')}</Sans>
        </View>
      </View>
      <Card style={{ paddingVertical: 4, paddingHorizontal: 16 }}>
        {rows.map((r, i) => (
          <Press key={r.label} onPress={r.go} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14, minHeight: 60, borderBottomWidth: i === rows.length - 1 ? 0 : 1, borderBottomColor: colors.lineSoft }}>
            <View style={{ flex: 1 }}>
              <Sans s={14} w={600}>{r.label}</Sans>
              <Sans s={12} c={colors.muted} style={{ marginTop: 2 }}>{r.sub}</Sans>
            </View>
            {r.badge ? (
              <View style={{ minWidth: 22, height: 22, borderRadius: 11, backgroundColor: colors.terra, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 }}>
                <Sans s={11} w={700} c={colors.card}>{r.badge}</Sans>
              </View>
            ) : null}
            <Chevron />
          </Press>
        ))}
      </Card>
      <Sans s={12} lh={1.5} c={colors.muted} style={{ paddingHorizontal: 4 }}>O Bornly organiza informações entre consultas. Não é serviço de emergência e não substitui o atendimento presencial nem o prontuário do seu médico.</Sans>
    </Screen>
  );
}
