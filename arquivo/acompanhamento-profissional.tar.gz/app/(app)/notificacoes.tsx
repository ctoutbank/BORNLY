import { View } from 'react-native';

import { useCare } from '@/care';
import { useStore } from '@/store';
import { colors } from '@/theme';
import { Card, PageHeader, Press, Sans, Screen } from '@/ui';

export default function Notificacoes() {
  const { s, set, flash } = useStore();
  const care = useCare();
  return (
    <Screen gap={18}>
      <PageHeader
        title="Notificações"
        fallback="/hoje"
        right={
          <Press
            onPress={() => {
              set({ notifSeen: true });
              flash('Notificações marcadas como lidas');
            }}
            style={{ minHeight: 44, justifyContent: 'center' }}>
            <Sans s={12} w={600} c={colors.terra}>Marcar como lidas</Sans>
          </Press>
        }
      />
      <Card style={{ paddingVertical: 4, paddingHorizontal: 16 }}>
        {care.notifications.map((n, i) => (
          <Press key={n.title + n.text} onPress={n.go} style={{ flexDirection: 'row', gap: 12, paddingVertical: 15, borderBottomWidth: i === care.notifications.length - 1 ? 0 : 1, borderBottomColor: colors.lineSoft }}>
            <View style={{ width: 8, height: 8, borderRadius: 4, marginTop: 6, backgroundColor: n.unread && !s.notifSeen ? colors.terra : 'transparent' }} />
            <View style={{ flex: 1, minWidth: 0 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 10 }}>
                <Sans s={14} w={600} style={{ flexShrink: 1 }}>{n.title}</Sans>
                <Sans s={11} c={colors.muted}>{n.time}</Sans>
              </View>
              <Sans s={13} lh={1.45} c={colors.mutedStrong} style={{ marginTop: 3 }}>{n.text}</Sans>
            </View>
          </Press>
        ))}
      </Card>
      <Card bg={colors.sand} radius={20} style={{ paddingVertical: 14, paddingHorizontal: 16 }}>
        <Sans s={12} lh={1.5} c={colors.body}>Na tela bloqueada aparece só “Você tem uma atualização no Bornly”. Nenhum dado de saúde fica visível.</Sans>
      </Card>
    </Screen>
  );
}
