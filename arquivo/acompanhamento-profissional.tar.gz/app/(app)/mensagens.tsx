import { useRouter } from 'expo-router';
import { TextInput, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';

import { useCare } from '@/care';
import { useStore } from '@/store';
import { colors, fonts } from '@/theme';
import { Card, CircleButton, PageHeader, Press, Sans, Screen } from '@/ui';

export default function Mensagens() {
  const { s, set } = useStore();
  const router = useRouter();
  const care = useCare();
  const send = () => {
    const text = s.msgDraft.trim();
    if (!text) return;
    const n = new Date();
    set((st) => ({ msgDraft: '', sentMessages: [...st.sentMessages, { who: 'me', text, time: `Hoje, ${n.getHours()}:${String(n.getMinutes()).padStart(2, '0')}` }] }));
  };
  return (
    <Screen gap={16}>
      <PageHeader title="Mensagens" sub="Dra. Helena Prado e equipe" fallback="/hoje" />
      <Card bg={colors.peach} radius={20} style={{ paddingVertical: 12, paddingHorizontal: 16, gap: 6, alignItems: 'flex-start' }}>
        <Sans s={12} lh={1.5} c={colors.terraText}>Respostas em dias úteis, das 8h às 18h. Não use para urgências.</Sans>
        <Press accessibilityRole="link" onPress={() => router.push('/sintomas')} hitSlop={8} style={{ minHeight: 36, justifyContent: 'center' }}>
          <Sans s={12} w={700} c={colors.terraDark} style={{ textDecorationLine: 'underline' }}>Ver sinais de alerta</Sans>
        </Press>
      </Card>
      <View style={{ gap: 12 }}>
        {care.allMessages.map((m, i) => {
          const me = m.who === 'me';
          return (
            <View key={i} style={{ alignItems: me ? 'flex-end' : 'flex-start', gap: 4 }}>
              <Sans s={11} c={colors.muted} style={{ paddingHorizontal: 8 }}>{me ? m.time : `${m.name} · ${m.time}`}</Sans>
              <View style={{ maxWidth: '84%', backgroundColor: me ? colors.ink : colors.card, borderRadius: 20, borderBottomRightRadius: me ? 6 : 22, borderBottomLeftRadius: me ? 22 : 6, paddingVertical: 12, paddingHorizontal: 15 }}>
                <Sans s={14} lh={1.5} c={me ? colors.bg : colors.ink}>{m.text}</Sans>
              </View>
            </View>
          );
        })}
      </View>
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center', marginTop: 6 }}>
        <TextInput
          value={s.msgDraft}
          onChangeText={(msgDraft) => set({ msgDraft })}
          onSubmitEditing={send}
          returnKeyType="send"
          accessibilityLabel="Escreva para a equipe"
          placeholder="Escreva para a equipe"
          placeholderTextColor={colors.muted}
          style={{ flex: 1, minWidth: 0, height: 52, borderRadius: 999, borderWidth: 1.5, borderColor: colors.line, backgroundColor: colors.card, paddingHorizontal: 18, fontSize: 14, color: colors.ink, fontFamily: fonts.sans400 }}
        />
        <CircleButton label="Enviar mensagem" bg={colors.ink} size={52} onPress={send}>
          <Svg width={22} height={22} viewBox="0 0 16 16"><Path d="M2 8h11M8.5 3.5L13 8l-4.5 4.5" stroke={colors.bg} strokeWidth={1.8} fill="none" strokeLinecap="round" strokeLinejoin="round" /></Svg>
        </CircleButton>
      </View>
    </Screen>
  );
}
